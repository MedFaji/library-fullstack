package net.medev.librarybackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
